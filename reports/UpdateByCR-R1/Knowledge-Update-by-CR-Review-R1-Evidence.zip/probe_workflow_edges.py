"""Independent bounded workflow edge cases using the installed distribution."""
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get('UCR_SOURCE', str(ROOT / 'source')))
sys.path.insert(0, str(SOURCE / 'tests'))
from cr_fixtures import project, decisions, ready, git, item
from knowledge.cr_workflow import Workflow
from knowledge.util import KnowledgeError

results = {}
with tempfile.TemporaryDirectory(prefix='ucr-auditor-refresh-') as directory:
    root, snapshot = project(directory)
    workflow = Workflow(root)
    state = ready(workflow, snapshot, decisions(snapshot))
    prepared = workflow.prepare(state['session'], state['revision'])
    old_candidate = prepared['proposal']['candidate']
    fresh = deepcopy(snapshot)
    fresh['pr']['discussion'].append({'id': 'new-review-comment', 'text': 'Reviewed the updated documentation.', 'reference': snapshot['pr']['url']})
    changed = workflow.sources(state['session'], fresh, prepared['revision'])
    reassessed = ready(workflow, fresh, decisions(fresh))
    try:
        result = workflow.prepare(state['session'], reassessed['revision'])
        error = None
    except KnowledgeError as exc:
        error = {'code': exc.code, 'details': exc.details}
        result = None
    results['refresh_after_prepare'] = {
        'before_refresh': prepared, 'after_refresh': changed, 'after_reassessment': reassessed,
        'old_candidate': old_candidate, 'retry_result': result, 'retry_error': error,
        'queue': workflow.store.status()['queue'],
        'own_candidate_reclassified_as_unrelated': error is not None and error['code'] == 'ucr-unrelated-pending-candidates'
            and old_candidate in error['details']['candidates'],
    }

with tempfile.TemporaryDirectory(prefix='ucr-auditor-same-file-') as directory:
    root, snapshot = project(directory)
    code = root / 'Retry.cs'
    code.write_text('public static class Retry {\n  public const int MaxAttempts = 4;\n  public static string PublicName() => "retry";\n}\n')
    git(root, 'add', '.'); git(root, 'commit', '-m', 'synthetic multi-member baseline')
    baseline = git(root, 'rev-parse', 'HEAD')
    code.write_text(code.read_text().replace('= 4;', '= 6;'))
    git(root, 'add', '.'); git(root, 'commit', '-m', 'synthetic constant-only change')
    head = git(root, 'rev-parse', 'HEAD')
    snapshot['pr'].update(base=baseline, head=head, merge=head)
    snapshot['target']['commit'] = head
    workflow = Workflow(root)
    state = workflow.start(cr=snapshot['cr']['url'], pr=snapshot['pr']['url'])
    state = workflow.sources(state['session'], snapshot, state['revision'])
    decision = item(snapshot, 'preserve-public-name', 'Preserve the public PublicName() signature and return value',
        'Retry.cs', category='nonchange', reason={'text': 'Existing callers depend on the public contract', 'refs': ['cr:req:body']})
    decision['anchors'][0].update(start=3, end=3, role='contract')
    try:
        result = workflow.analyze(state['session'], [decision], state['revision'])
        error = None
    except KnowledgeError as exc:
        result = None; error = {'code': exc.code, 'details': exc.details}
    results['unchanged_member_in_modified_file'] = {
        'baseline': git(root, 'show', baseline + ':Retry.cs'),
        'head': git(root, 'show', head + ':Retry.cs'),
        'unchanged_anchored_line': git(root, 'show', baseline + ':Retry.cs').splitlines()[2]
            == git(root, 'show', head + ':Retry.cs').splitlines()[2],
        'decision': decision, 'result': result, 'error': error,
    }

with tempfile.TemporaryDirectory(prefix='ucr-auditor-native-sequence-') as directory:
    root, snapshot = project(directory)
    workflow = Workflow(root)
    first = workflow.start(cr=snapshot['cr']['url'], pr=snapshot['pr']['url'], host_session='same-native-chat')
    first = workflow.sources(first['session'], snapshot, first['revision'])
    first = workflow.analyze(first['session'], [item(snapshot, 'retry-limit', 'Four attempts', 'Retry.cs',
        reason={'text': 'Bound transient operation work', 'refs': ['cr:req:body']})], first['revision'])
    plan = workflow.prepare(first['session'], first['revision'])
    saved = workflow.apply(plan['session'], plan['proposal']['plan'], plan['revision'])
    second = workflow.start(cr='https://github.com/synthetic/project/issues/10',
        pr='https://github.com/synthetic/project/pull/11', host_session='same-native-chat')
    try:
        third = workflow.start(host_session='same-native-chat')
        error = None
    except KnowledgeError as exc:
        third = None; error = {'code': exc.code, 'details': exc.details}
    rebind_errors = {}
    for name, kwargs in (
        ('explicit_second_links', {'cr': second['links']['cr'], 'pr': second['links']['pr']}),
        ('explicit_second_resume', {'session': second['session']}),
    ):
        try:
            workflow.start(host_session='same-native-chat', **kwargs)
            rebind_errors[name] = None
        except KnowledgeError as exc:
            rebind_errors[name] = {'code': exc.code, 'details': exc.details}
    results['same_native_chat_two_workflows'] = {'first_saved': saved['state'], 'second': second,
        'next_no_argument_command': third, 'error': error, 'rebind_errors': rebind_errors}

(ROOT / 'evidence' / 'workflow-edge-probes.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: {'error': value.get('retry_error') or value.get('error'),
    'reproduced': value.get('own_candidate_reclassified_as_unrelated') or value.get('unchanged_anchored_line') or bool(value.get('error'))}
    for key, value in results.items()}))
