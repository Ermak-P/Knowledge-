"""Independent installed-package regression probe; synthetic repositories only."""
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get('UCR_SOURCE', str(ROOT / 'source')))
sys.path.insert(0, str(SOURCE / 'tests'))
from cr_fixtures import project, decisions, ready, git, item
from knowledge.cr_workflow import Workflow
import knowledge


def commit(workflow, state):
    plan = workflow.prepare(state['session'], state['revision'])
    return workflow.apply(plan['session'], plan['proposal']['plan'], plan['revision'])


with tempfile.TemporaryDirectory(prefix='ucr-auditor-proposal-') as directory:
    root, original = project(directory)
    workflow = Workflow(root)
    first = commit(workflow, ready(workflow, original, decisions(original)))
    claim_id = next(r['id'] for r in first['receipt']['records'] if r['id'].endswith('.retry-limit'))
    before = workflow.store.lookup('claims', claim_id)
    before_context = workflow.store.context('transient retry attempts', max_items=20)

    target_branch = git(root, 'branch', '--show-current')
    git(root, 'checkout', '-b', 'proposed-six-attempts')
    code_path = root / 'Retry.cs'
    code_path.write_text(code_path.read_text().replace('= 4;', '= 6;'), encoding='utf-8')
    git(root, 'add', 'Retry.cs')
    git(root, 'commit', '-m', 'synthetic unmerged proposal: six attempts')
    proposal_head = git(root, 'rev-parse', 'HEAD')
    git(root, 'checkout', target_branch)

    proposed = deepcopy(original)
    proposed['pr'].update(url='https://github.com/synthetic/project/pull/9', id='9',
        base=original['target']['commit'], head=proposal_head, merge=None, status='open',
        description='Proposes six attempts for https://github.com/synthetic/project/issues/7')
    proposal_item = item(proposed, 'retry-limit', 'Prefer six total transient operation attempts',
        'Retry.cs', reason={'text': 'The new proposed budget would allow six attempts', 'refs': ['pr:description']},
        terms=['retry', 'transient', 'attempts'])
    proposal_item['anchors'][0]['revision'] = proposal_head
    second = commit(workflow, ready(workflow, proposed, [proposal_item]))
    after = workflow.store.lookup('claims', claim_id)
    after_context = workflow.store.context('transient retry attempts', max_items=20)
    result = {
        'profile': 'independent-unmerged-successor-PR-same-CR',
        'installed_knowledge': knowledge.__file__,
        'merged_pr': original['pr'], 'unmerged_pr': proposed['pr'],
        'target_commit_before': original['target']['commit'], 'target_commit_after': git(root, 'rev-parse', 'HEAD'),
        'target_source_after': code_path.read_text(),
        'claim_id': claim_id, 'before_lookup': before, 'after_lookup': after,
        'before_context': before_context, 'after_context': after_context,
        'first_receipt': first, 'second_receipt': second,
        'confirmed_target_fact_overwritten': before['record']['status'] == 'CONFIRMED'
            and after['record']['status'] == 'NEEDS_HUMAN_CONFIRMATION'
            and original['target']['commit'] == git(root, 'rev-parse', 'HEAD')
            and not any(c['id'] == claim_id for c in after_context['claims']),
    }
    destination = ROOT / 'evidence' / 'proposal-scope-regression.json'
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('profile', 'claim_id', 'target_source_after', 'confirmed_target_fact_overwritten')}))
    assert result['confirmed_target_fact_overwritten'], 'Bug was not reproduced'
