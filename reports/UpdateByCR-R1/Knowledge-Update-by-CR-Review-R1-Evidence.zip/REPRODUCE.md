# Independent update-by-CR audit evidence

Reviewed head: `3c9d1ed6aa43091866e1f4873e78d0e31e58b058` on `Ermak-P/Knowledge-`, branch `codex/update-by-cr`.

This packet contains audit artifacts, not a patched product or a repository copy. Obtain the repository at the reviewed commit and its official `reports/UpdateByCR/distribution/knowledge-harness-0.5.0rc1.zip` through your existing GitHub access. ZIP SHA-256: `b1b7eac4aa0d4d950f0613986ff223cb2de482ba708327f3813b3add617a34e0`.

Install the delivered kit outside the checkout using its `install.py install --env ABSOLUTE_ENV --profile full`. Use that environment's Python below. The full original test suite uses the existing qualification dependencies; use the repository's setup guidance. Do not replace the candidate knowledge/harness packages with older installed copies.

## Audit commands

```bash
# Normal authored tests, using the installed candidate:
/path/to/env/bin/python -B -m unittest discover -s tests -p 'test_update*cr*.py' -v
/path/to/env/bin/python -B -m unittest discover -s tests -v

# Independent probes, from this extracted packet:
UCR_SOURCE=/path/to/Knowledge- /path/to/env/bin/python -B probe_proposal_scope.py
UCR_SOURCE=/path/to/Knowledge- /path/to/env/bin/python -B probe_workflow_edges.py
```

On Windows, use `env\Scripts\python.exe` and set `$env:UCR_SOURCE` in PowerShell. The scripts import only synthetic fixture constructors from that checkout; product imports come from the installed environment. They create and remove isolated temporary Git repositories and write results under this packet's `evidence/` directory. Git must be available. They do not use tracker credentials, services, models, or production data.

`probe_proposal_scope.py` asserts that the **reviewed bug is reproduced** and prints `confirmed_target_fact_overwritten: true`. It is an audit demonstration, not a passing acceptance test for a future fix. A fixed implementation should instead preserve the current target claim or refuse a destructive proposal write. `probe_workflow_edges.py` records structured outcomes for three additional cases; inspect the corresponding fields rather than treating process exit zero as correctness.

## Evidence map

| File | Meaning |
|---|---|
| `evidence/proposal-scope-regression.json` | Installed import; before/after claim revisions and normal context; distinct merged/open PRs; target commit/source unchanged |
| `evidence/workflow-edge-probes.json` | Prepared candidate stranded after refresh; unchanged contract rejected inside a modified file; ambiguous sequential native workflow bindings |
| `evidence/independent-byte-verification.json` | Independently computed source identity, ZIP SHA-256, all 248 source and 61 installed asset comparisons |
| `evidence/knowledge-only/result.json` | Actual persistence/retrieval with Harness and MCP absent |
| `evidence/focused.log` | 27 focused authored tests PASS |
| `evidence/full-suite-complete-fixtures.log` | 389 total, 378 PASS / 11 SKIP in the complete local run |
| `evidence/full-suite.log` | Earlier audit setup failure: one missing materialized historical installer fixture, subsequently restored exactly |
| `evidence/install.log`, `evidence/knowledge-only-install.log` | Official kit installation profiles |
| `evidence/upstream-provenance.json` | Retrieved upstream source/installed manifests, CI job metadata, and retained controlled/native/provider profiles; distinguish from independently executed results |
| `evidence/live-ci-run.json` | Live hosted CI run state and exact implementation commit |
| `evidence/audit-summary.json` | Final independent audit result and scope |
| `SHA256SUMS.json` | Packet artifact hashes |

The audit host is Linux/Python 3.12. Native Windows results and actual OpenCode 1.19.6 execution are upstream retained evidence, with live CI status checked independently. No local .NET SDK/OpenCode executable or approved live semantic model was available for a new execution of those profiles. Controlled planner or provider recordings must not be presented as live-model equivalence.
