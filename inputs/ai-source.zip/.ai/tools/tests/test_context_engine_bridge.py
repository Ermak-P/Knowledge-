"""Regression checks for the cross-lingual (RU->EN) bridge in ContextEngine.expand().

The bridge was added in Stage 7.4: a Russian query token that starts with a curated
RU stem (see context_engine.CROSS_LINGUAL) is bridged to the EN canonical term so the
English claim vocabulary becomes reachable from a Russian prompt.

These checks lock the bridge's CONTRACT with a disposable synthetic repository (the
host canonical records are never touched):
  1. A Russian query reaches an English-only technical claim (only via the bridge).
  2. English queries retain their behaviour (the bridge is a no-op for them).
  3. Budget enforcement and truncation metadata stay accurate on the expanded pool.
  4. Unrelated Russian queries do not acquire arbitrary domain matches (no bridge stem
     => identical results with/without the bridge; a bridge stem only reaches claims
     that actually contain the bridged term).

Run: python -B -m unittest discover -s .ai/tools/tests -p 'test_*.py'
"""
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

import context_engine
import kb
from context_engine import ContextEngine
from population_normalize import GROUPS
from population_transaction import canonical_json

PROV = {'actor': 'test-author', 'method': 'test-method'}

# English-only technical claims: reachable from a Russian query ONLY through the bridge.
CLAIMS = [
    {'id': 'arch.content-stats-clickhouse',
     'statement': 'Content statistics are stored in ClickHouse through Kafka.',
     'type': 'architecture', 'status': 'CONFIRMED', 'evidence': ['ev.stats'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []},
    {'id': 'arch.content-distribution-process',
     'statement': 'The content distribution process uploads signed zip archives to the CDN.',
     'type': 'architecture', 'status': 'CONFIRMED', 'evidence': ['ev.dist'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []},
    # Unrelated domain claim: must NOT be pulled in by a bridge stem that is absent here.
    {'id': 'arch.deployment-pipeline',
     'statement': 'The deployment pipeline builds the backend services.',
     'type': 'architecture', 'status': 'CONFIRMED', 'evidence': ['ev.deploy'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []},
]
EVIDENCE = [
    {'id': 'ev.stats', 'type': 'direct-technical', 'status': 'active',
     'source': 'IPM/Src/Backend/Statistics/ClickHouseStats.cs', 'provenance': PROV,
     'captured_at': '2026-10-19T12:00:00Z', 'location': 'IPM/Src/Backend/Statistics/ClickHouseStats.cs (Store)',
     'description': 'Content statistics stored in ClickHouse.', 'substantiates': ['arch.content-stats-clickhouse']},
    {'id': 'ev.dist', 'type': 'direct-technical', 'status': 'active',
     'source': 'IPM/Src/Backend/DistributionService/Pipeline.cs', 'provenance': PROV,
     'captured_at': '2026-10-19T12:00:00Z', 'location': 'IPM/Src/Backend/DistributionService/Pipeline.cs (Upload)',
     'description': 'Distribution process uploads zip to CDN.', 'substantiates': ['arch.content-distribution-process']},
    {'id': 'ev.deploy', 'type': 'direct-technical', 'status': 'active',
     'source': 'IPM/Src/Backend/Deployment/Pipeline.cs', 'provenance': PROV,
     'captured_at': '2026-10-19T12:00:00Z', 'location': 'IPM/Src/Backend/Deployment/Pipeline.cs (Build)',
     'description': 'Deployment pipeline builds backend.', 'substantiates': ['arch.deployment-pipeline']},
]


def make_repo(root):
    errors = kb.init(root / '.ai')
    assert not errors, errors
    base = root / '.ai'
    for record in CLAIMS:
        (base / GROUPS['claims'] / (record['id'] + '.json')).write_text(
            canonical_json(record), encoding='utf-8')
    for record in EVIDENCE:
        (base / GROUPS['evidence'] / (record['id'] + '.json')).write_text(
            canonical_json(record), encoding='utf-8')


class CrossLingualBridgeTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory(prefix='kb-bridge-')
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name) / 'target'
        self.root.mkdir()
        make_repo(self.root)
        self.engine = ContextEngine()

    def query(self, task, bridge, **kwargs):
        """Run a query with the bridge enabled or disabled (identical KB state)."""
        saved = context_engine.CROSS_LINGUAL
        context_engine.CROSS_LINGUAL = dict(saved) if bridge else {}
        try:
            return self.engine.query(self.root, task, **kwargs)
        finally:
            context_engine.CROSS_LINGUAL = saved

    def ids(self, result):
        return [c['id'] for c in result['claims']]

    # 1. A Russian query reaches an English-only technical claim (only via the bridge).
    def test_russian_query_reaches_english_claim(self):
        on = self.query('Где хранится статистика контента?', bridge=True)
        self.assertIn('arch.content-stats-clickhouse', self.ids(on))
        # Without the bridge the English claim is not lexically reachable from the RU prompt.
        off = self.query('Где хранится статистика контента?', bridge=False)
        self.assertNotIn('arch.content-stats-clickhouse', self.ids(off))

    def test_russian_distribution_query_reaches_english_claim(self):
        on = self.query('Как работает процесс дистрибуции контента?', bridge=True)
        self.assertIn('arch.content-distribution-process', self.ids(on))
        off = self.query('Как работает процесс дистрибуции контента?', bridge=False)
        self.assertNotIn('arch.content-distribution-process', self.ids(off))

    # 2. English queries retain their behaviour (the bridge is a no-op for them).
    def test_english_query_retains_behavior(self):
        task = 'How is content statistics stored in ClickHouse?'
        on = self.query(task, bridge=True)
        off = self.query(task, bridge=False)
        self.assertEqual(self.ids(on), self.ids(off))
        self.assertIn('arch.content-stats-clickhouse', self.ids(on))

    # 3. Budget enforcement and truncation metadata stay accurate on the expanded pool.
    def test_bridge_budget_enforcement_and_truncation(self):
        task = 'Где хранится статистика контента?'
        full = self.query(task, bridge=True, max_tokens=2000)
        self.assertLessEqual(full['budget']['estimated_tokens'], 2000)
        # The expanded (bridged) candidate pool is reported in truncation.candidates and is
        # strictly larger than the non-bridged pool for the same query.
        self.assertGreater(full['truncation']['candidates'],
                           self.query(task, bridge=False, max_tokens=2000)['truncation']['candidates'])
        # A tiny budget is still enforced and reports the budget-exhausted reason.
        tiny = self.query(task, bridge=True, max_tokens=1)
        self.assertEqual(tiny['claims'], [])
        self.assertEqual(tiny['truncation']['reason'], 'budget-exhausted-by-envelope')

    # 4a. Unrelated Russian query (no bridge stem) is a no-op: identical with/without the bridge.
    def test_russian_no_bridge_stem_is_noop(self):
        task = 'Как работает аудитория?'  # no CROSS_LINGUAL stem present
        on = self.query(task, bridge=True)
        off = self.query(task, bridge=False)
        self.assertEqual(self.ids(on), self.ids(off))
        self.assertEqual(on['truncation']['candidates'], off['truncation']['candidates'])

    # 4b. A bridge stem only reaches claims that actually contain the bridged term (bounded).
    def test_bridge_overmatch_bounded_to_bridged_term(self):
        # "процесс" -> "process": reaches the distribution claim (contains "process") but must
        # NOT drag in the unrelated deployment claim (no "process" token).
        on = self.query('Процесс деплоя', bridge=True)
        on_ids = set(self.ids(on))
        self.assertNotIn('arch.deployment-pipeline', on_ids)
        self.assertIn('arch.content-distribution-process', on_ids)


if __name__ == '__main__':
    unittest.main()
