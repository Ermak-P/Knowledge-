"""Tests for the local stdio MCP server (kb_mcp.py), Stage 6.2.

Uses actual MCP client sessions (mcp SDK over stdio) against a disposable
synthetic repository (same fixture as the Context Engine tests, including the
historical TargetId conflict pair). The host repository's canonical records
are never touched.

Run: python -B -m unittest discover -s .ai/tools/tests -p 'test_*.py'
"""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TESTS = Path(__file__).resolve().parent
TOOLS = TESTS.parent
if str(TOOLS) not in sys.path:
    sys.path.insert(0, str(TOOLS))
if str(TESTS) not in sys.path:
    sys.path.insert(0, str(TESTS))

from context_engine import ContextEngine  # noqa: E402
from test_context_engine import make_repo  # noqa: E402
from mcp import ClientSession, StdioServerParameters, stdio_client  # noqa: E402

SERVER = TOOLS / 'kb_mcp.py'
SERVER_NAME = 'ipm-knowledge'
TOOL_NAMES = {'knowledge_context', 'knowledge_get_claim', 'knowledge_get_evidence'}


def server_params(root):
    return StdioServerParameters(command=sys.executable, args=['-B', str(SERVER),
                                                               '--root', str(root)])


def call_json(result):
    """Parse the single JSON text content of a tool result."""
    assert len(result.content) == 1, result.content
    return json.loads(result.content[0].text)


def raw_exchange(root, requests, close_stdin=True, timeout=60):
    """Raw JSON-RPC exchange over stdio; returns (stdout_lines, exit_code, stderr).

    Every non-notification request expects exactly one response line.
    """
    proc = subprocess.Popen(
        [sys.executable, '-B', str(SERVER), '--root', str(root)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding='utf-8')
    lines = []
    try:
        for obj in requests:
            proc.stdin.write(json.dumps(obj) + '\n')
            proc.stdin.flush()
            if 'id' in obj:
                lines.append(proc.stdout.readline())
    finally:
        if close_stdin and proc.stdin and not proc.stdin.closed:
            proc.stdin.close()
        proc.wait(timeout=timeout)
    stderr = proc.stderr.read()
    proc.stdout.close()
    proc.stderr.close()
    return lines, proc.returncode, stderr


class KbMcpServerTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory(prefix='kb-mcp-')
        cls.root = Path(cls._tmp.name) / 'target'
        cls.root.mkdir()
        make_repo(cls.root)

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    async def with_session(self, fn):
        async with stdio_client(server_params(self.root)) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                return await fn(session)

    def tree_digest(self):
        digest = hashlib.sha256()
        for path in sorted(self.root.rglob('*')):
            if path.is_file():
                digest.update(path.relative_to(self.root).as_posix().encode('utf-8'))
                digest.update(path.read_bytes())
        return digest.hexdigest()

    # 1. Initialize handshake.
    async def test_initialize_handshake(self):
        async with stdio_client(server_params(self.root)) as (read, write):
            async with ClientSession(read, write) as session:
                info = await session.initialize()
                self.assertEqual(info.serverInfo.name, SERVER_NAME)
                self.assertTrue(info.protocolVersion)
                self.assertTrue(info.serverInfo.version)

    # 2. Tool discovery.
    async def test_tool_discovery(self):
        async def check(session):
            return (await session.list_tools()).tools

        tools = await self.with_session(check)
        self.assertEqual({t.name for t in tools}, TOOL_NAMES)
        schemas = {t.name: t.inputSchema for t in tools}
        self.assertEqual(schemas['knowledge_context']['required'], ['task'])
        self.assertEqual(schemas['knowledge_get_claim']['required'], ['claim_id'])
        self.assertEqual(schemas['knowledge_get_evidence']['required'], ['evidence_id'])
        for tool in tools:
            self.assertTrue(tool.description.strip())
            self.assertIn('type', schemas[tool.name])

    # 3 + 6. Schema and successful execution; compact context matches the engine.
    async def test_knowledge_context_matches_engine(self):
        task, scope, max_tokens = 'статистика', ['ClickHouse'], 1500

        async def check(session):
            return await session.call_tool('knowledge_context', {
                'task': task, 'scope': scope, 'max_tokens': max_tokens})

        result = await self.with_session(check)
        self.assertFalse(result.isError)
        data = call_json(result)
        self.assertTrue(data['ok'])
        self.assertEqual(data['view'], 'compact')
        self.assertEqual(data['result'], 'matches')
        self.assertEqual(data['claims'][0]['id'], 'business.stats.storage')
        self.assertTrue(data['knowledge_base']['fingerprint'].startswith('sha256:'))
        self.assertEqual(data['budget']['estimation'], 'utf8-bytes/4')
        self.assertIn('estimate', data['budget']['note'])
        self.assertLessEqual(data['budget']['estimated_tokens'], max_tokens)

        # Parity with the existing Context Engine (the MCP layer only adds budget.note).
        expected = ContextEngine().query(self.root, task, scope=scope,
                                         max_tokens=max_tokens, compact=True)
        data['budget'].pop('note')
        self.assertEqual(json.dumps(data, sort_keys=True, ensure_ascii=False),
                         json.dumps(expected, sort_keys=True, ensure_ascii=False))

    # 4. Claim ID lookup.
    async def test_get_claim_lookup(self):
        async def check(session):
            return await session.call_tool('knowledge_get_claim',
                                           {'claim_id': 'term.targetid.sha1'})

        data = call_json(await self.with_session(check))
        self.assertTrue(data['ok'])
        claim = data['claim']
        self.assertEqual(claim['id'], 'term.targetid.sha1')
        self.assertEqual(claim['status'], 'CONFIRMED')
        self.assertIn('SHA1', claim['statement'])
        self.assertEqual(claim['provenance']['actor'], 'test-author')
        self.assertEqual([e['id'] for e in data['evidence']], ['ev.targetid'])
        self.assertEqual(data['evidence'][0]['source'],
                         'IPM/Src/Common/Entities/Targets/TargetId.cs')
        self.assertEqual([c['partner_id'] for c in data['conflicts']], ['term.targetid.legacy'])
        self.assertEqual(data['conflicts'][0]['partner_status'], 'NEEDS_HUMAN_CONFIRMATION')
        self.assertIn('not an active rule', data['conflicts'][0]['note'])

    # 5. Evidence ID lookup.
    async def test_get_evidence_lookup(self):
        async def check(session):
            return await session.call_tool('knowledge_get_evidence',
                                           {'evidence_id': 'ev.targetid'})

        data = call_json(await self.with_session(check))
        self.assertTrue(data['ok'])
        evidence = data['evidence']
        self.assertEqual(evidence['id'], 'ev.targetid')
        self.assertEqual(evidence['type'], 'direct-technical')
        self.assertEqual(evidence['status'], 'active')
        self.assertEqual(evidence['source'], 'IPM/Src/Common/Entities/Targets/TargetId.cs')
        self.assertIn('TargetId.Create', evidence['location'])
        self.assertEqual(evidence['provenance']['method'], 'test-method')
        self.assertEqual(sorted(evidence['substantiates']),
                         ['term.targetid.rationale', 'term.targetid.sha1'])

    # 7. Historical TargetId conflicts.
    async def test_targetid_conflicts(self):
        async def check(session):
            return await session.call_tool('knowledge_context',
                                           {'task': 'TargetId SHA1 hash'})

        data = call_json(await self.with_session(check))
        self.assertTrue(data['ok'])
        ids = [c['id'] for c in data['claims']]
        self.assertIn('term.targetid.sha1', ids)
        self.assertNotIn('term.targetid.legacy', ids)
        conflict = next(c for c in data['conflicts'] if c['partner_id'] == 'term.targetid.legacy')
        self.assertEqual(conflict['claim_id'], 'term.targetid.sha1')
        self.assertEqual(conflict['partner_status'], 'NEEDS_HUMAN_CONFIRMATION')
        self.assertFalse(conflict['partner_confirmed'])
        self.assertIn('not an active rule', conflict['note'])

    # 8. Unconfirmed knowledge.
    async def test_unconfirmed_knowledge(self):
        async def check(session):
            default = call_json(await session.call_tool(
                'knowledge_context', {'task': 'TargetId SHA1 hash'}))
            opened = call_json(await session.call_tool(
                'knowledge_context', {'task': 'TargetId SHA1 hash',
                                      'include_unconfirmed': True}))
            return default, opened

        default, opened = await self.with_session(check)
        self.assertNotIn('term.targetid.legacy', [c['id'] for c in default['claims']])
        legacy = next(c for c in opened['claims'] if c['id'] == 'term.targetid.legacy')
        self.assertEqual(legacy['status'], 'NEEDS_HUMAN_CONFIRMATION')
        self.assertFalse(legacy['confirmed'])

    # 9. Unknown IDs and invalid inputs.
    async def test_unknown_ids_and_invalid_inputs(self):
        async def check(session):
            calls = [
                ('knowledge_get_claim', {'claim_id': 'nope.missing'}, 'claim-id-not-found'),
                ('knowledge_get_evidence', {'evidence_id': 'nope.missing'}, 'evidence-id-not-found'),
                ('knowledge_get_claim', {'claim_id': '../../etc/passwd'}, 'malformed-claim-id'),
                ('knowledge_get_claim', {'claim_id': 'a' * 129}, 'malformed-claim-id'),
                ('knowledge_get_evidence', {'evidence_id': 'C:\\Windows\\system32'},
                 'malformed-evidence-id'),
                ('knowledge_context', {'task': '   '}, 'task-must-be-a-non-empty-string'),
                ('knowledge_context', {'task': 'x' * 2001}, 'task-too-long'),
                ('knowledge_context', {'task': 'TargetId', 'max_tokens': 0},
                 'max-tokens-must-be-a-positive-integer'),
                ('knowledge_context', {'task': 'TargetId', 'max_tokens': 999999},
                 'max-tokens-exceeds-limit'),
                ('knowledge_context', {'task': 'TargetId', 'max_items': 0},
                 'max-items-must-be-a-positive-integer'),
                ('knowledge_context', {'task': 'TargetId', 'max_items': 999},
                 'max-items-exceeds-limit'),
                ('knowledge_context', {'task': 'TargetId', 'scope': ['x' * 201]},
                 'scope-invalid'),
                ('knowledge_context', {'task': 'TargetId', 'scope': [f's{i}' for i in range(11)]},
                 'scope-invalid'),
            ]
            return [call_json(await session.call_tool(name, args)) for name, args, _ in calls], calls

        results, calls = await self.with_session(check)
        for data, (_, _, code) in zip(results, calls):
            self.assertFalse(data['ok'], (code, data))
            self.assertEqual(data['errors'], [code], code)

    # 10. Budget limits.
    async def test_budget_limits(self):
        async def check(session):
            tiny = call_json(await session.call_tool(
                'knowledge_context', {'task': 'TargetId', 'max_tokens': 1}))
            default = call_json(await session.call_tool(
                'knowledge_context', {'task': 'TargetId'}))
            capped = call_json(await session.call_tool(
                'knowledge_context', {'task': 'TargetId', 'max_tokens': 8000}))
            return tiny, default, capped

        tiny, default, capped = await self.with_session(check)
        self.assertEqual(tiny['claims'], [])
        self.assertEqual(tiny['truncation']['reason'], 'budget-exhausted-by-envelope')
        self.assertLessEqual(default['budget']['estimated_tokens'], 1500)
        self.assertTrue(default['claims'])
        self.assertLessEqual(capped['budget']['estimated_tokens'], 8000)

    # 12. Deterministic responses (separate server processes).
    async def test_deterministic_responses(self):
        async def check(session):
            context = await session.call_tool('knowledge_context',
                                              {'task': 'How is TargetId generated?'})
            claim = await session.call_tool('knowledge_get_claim',
                                            {'claim_id': 'term.targetid.sha1'})
            return context.content[0].text, claim.content[0].text

        first = await self.with_session(check)
        second = await self.with_session(check)
        self.assertEqual(first, second)

    # 13. Windows paths.
    async def test_windows_paths(self):
        if os.name != 'nt':
            self.skipTest('Windows path handling test requires Windows')
        self.assertIn('\\', str(self.root))

        async def check(session):
            context = call_json(await session.call_tool(
                'knowledge_context', {'task': 'TargetId'}))
            evidence = call_json(await session.call_tool(
                'knowledge_get_evidence', {'evidence_id': 'ev.targetid'}))
            return context, evidence

        context, evidence = await self.with_session(check)
        for ref in context['evidence']:
            self.assertNotIn('\\', ref['source'])
            self.assertNotIn('\\', ref['location'] or '')
        self.assertNotIn('\\', evidence['evidence']['source'])
        self.assertNotIn('\\', evidence['evidence']['location'] or '')

    # 14. No unexpected file modifications.
    async def test_no_file_modifications(self):
        before = self.tree_digest()

        async def check(session):
            await session.call_tool('knowledge_context', {'task': 'How is TargetId generated?'})
            await session.call_tool('knowledge_get_claim', {'claim_id': 'term.targetid.sha1'})
            await session.call_tool('knowledge_get_evidence', {'evidence_id': 'ev.targetid'})
            await session.call_tool('knowledge_get_claim', {'claim_id': 'nope.missing'})

        await self.with_session(check)
        self.assertEqual(self.tree_digest(), before)

    # 11. No stdout contamination (raw protocol: every stdout line is JSON-RPC).
    def test_no_stdout_contamination(self):
        requests = [
            {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
                'protocolVersion': '2025-06-18', 'capabilities': {},
                'clientInfo': {'name': 'test', 'version': '0'}}},
            {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
            {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list', 'params': {}},
            {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {
                'name': 'knowledge_context', 'arguments': {'task': 'TargetId'}}},
        ]
        lines, exit_code, stderr = raw_exchange(self.root, requests)
        self.assertEqual(exit_code, 0, stderr)
        self.assertEqual(len(lines), 3)
        for line in lines:
            message = json.loads(line)  # raises on any non-JSON-RPC stdout line
            self.assertEqual(message.get('jsonrpc'), '2.0')

    # 15. Server lifecycle and clean shutdown.
    def test_lifecycle_clean_shutdown(self):
        requests = [
            {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
                'protocolVersion': '2025-06-18', 'capabilities': {},
                'clientInfo': {'name': 'test', 'version': '0'}}},
            {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
            {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list', 'params': {}},
        ]
        lines, exit_code, stderr = raw_exchange(self.root, requests)
        self.assertEqual(exit_code, 0, stderr)
        self.assertEqual(len(lines), 2)

    def test_startup_invalid_root(self):
        missing = self.root / 'does-not-exist'
        lines, exit_code, stderr = raw_exchange(missing, [], close_stdin=True)
        self.assertEqual(exit_code, 2)
        self.assertEqual(lines, [])  # nothing on stdout before a valid session
        self.assertIn('invalid-root', stderr)


if __name__ == '__main__':
    unittest.main()
