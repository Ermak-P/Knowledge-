"""Native tests for Context Engine v1 (read-only retrieval and context assembly).

Run: python -B -m unittest discover -s .ai/tools/tests -p 'test_*.py'
Fixtures are disposable synthetic repositories in a temp directory on the local
filesystem; the host repository's canonical records are never touched.
"""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

import kb
from context_engine import ContextEngine, ContextEngineError
from population_normalize import GROUPS
from population_transaction import canonical_json

PROV = {'actor': 'test-author', 'method': 'test-method'}

CLAIMS = [
    {'id': 'term.targetid.sha1',
     'statement': 'TargetId is a SHA1 hash of userId or licenseId (TargetId.Create, TargetId.cs).',
     'type': 'technical_fact', 'status': 'CONFIRMED', 'evidence': ['ev.targetid'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [],
     'conflicts_with': ['term.targetid.legacy']},
    {'id': 'term.targetid.rationale',
     'statement': 'TargetId uses SHA1 because of legacy.',
     'type': 'technical_fact', 'status': 'CONFIRMED', 'evidence': ['ev.targetid'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []},
    {'id': 'term.targetid.legacy',
     'statement': 'TargetId is a SHA1 of localization+licenseId+licenseActivationId (historical composition).',
     'type': 'technical_fact', 'status': 'NEEDS_HUMAN_CONFIRMATION', 'evidence': ['ev.legacy'],
     'provenance': PROV, 'last_verified': None, 'depends_on': [],
     'conflicts_with': ['term.targetid.sha1']},
    {'id': 'rel.campaign-states',
     'statement': 'Campaign state transitions are defined in ContentGroupStateHelper.AvailableCampaignStateChanges.',
     'type': 'architecture', 'status': 'CONFIRMED', 'evidence': ['ev.campaign'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []},
    {'id': 'business.stats.storage',
     'statement': 'Статистика хранится в ClickHouse через Kafka.',
     'type': 'business_rule', 'status': 'CONFIRMED', 'evidence': ['ev.stats'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []},
    # Generic business-domain claim about "targets" (no TargetId identifier): used to
    # verify that an exact technical identifier outranks generic domain vocabulary,
    # while a broader domain query about targets still retrieves this claim.
    {'id': 'business.workflow.targets',
     'statement': 'Business workflow: a campaign is created first, then targets are published '
                  'to specify who receives the content.',
     'type': 'business_rule', 'status': 'CONFIRMED', 'evidence': ['ev.workflow'],
     'provenance': PROV, 'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []},
]
EVIDENCE = [
    {'id': 'ev.targetid', 'type': 'direct-technical', 'status': 'active',
     'source': 'IPM/Src/Common/Entities/Targets/TargetId.cs',
     'provenance': PROV, 'captured_at': '2026-10-19T12:00:00Z',
     'location': 'IPM/Src/Common/Entities/Targets/TargetId.cs (TargetId.Create)',
     'description': 'TargetId.Create computes the SHA1 hash.',
     'substantiates': ['term.targetid.sha1', 'term.targetid.rationale']},
    {'id': 'ev.legacy', 'type': 'direct-technical', 'status': 'superseded',
     'source': '.ai_old/legacy.md',
     'provenance': PROV, 'captured_at': '2026-10-01T12:00:00Z',
     'location': '.ai_old/legacy.md (Sha1Hash)',
     'description': 'Legacy composition of the TargetId hash.',
     'substantiates': ['term.targetid.legacy']},
    {'id': 'ev.campaign', 'type': 'direct-technical', 'status': 'active',
     'source': 'IPM/Src/Common/Entities/Management/ContentGroupStateHelper.cs',
     'provenance': PROV, 'captured_at': '2026-10-19T12:00:00Z',
     'location': 'IPM/Src/Common/Entities/Management/ContentGroupStateHelper.cs (AvailableCampaignStateChanges)',
     'description': 'Campaign state transition graph.',
     'substantiates': ['rel.campaign-states']},
    {'id': 'ev.stats', 'type': 'direct-authoritative', 'status': 'active',
     'source': 'ipm-kb/interview.md',
     'provenance': PROV, 'captured_at': '2026-10-19T12:00:00Z',
     'location': 'ipm-kb/interview.md (Q10)',
     'description': 'Статистика отображается и хранится в ClickHouse.',
     'substantiates': ['business.stats.storage']},
    {'id': 'ev.workflow', 'type': 'direct-authoritative', 'status': 'active',
     'source': 'ipm-kb/workflow.md',
     'provenance': PROV, 'captured_at': '2026-10-19T12:00:00Z',
     'location': 'ipm-kb/workflow.md (Q3)',
     'description': 'Campaign-first, targets-published-after workflow.',
     'substantiates': ['business.workflow.targets']},
]


def make_repo(root):
    errors = kb.init(root / '.ai')
    assert not errors, errors
    base = root / '.ai'
    for record in CLAIMS:
        (base / GROUPS['claims'] / (record['id'] + '.json')).write_text(
            canonical_json(record), encoding='utf-8')
    for record in EVIDENCE:
        (base / GROUPS['evidence'] / (record['id'] + '.json')).write_text(
            canonical_json(record), encoding='utf-8')


class ContextEngineTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory(prefix='kb-context-')
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name) / 'target'
        self.root.mkdir()
        make_repo(self.root)
        self.engine = ContextEngine()

    def query(self, task, **kwargs):
        return self.engine.query(self.root, task, **kwargs)

    def tree_digest(self):
        digest = hashlib.sha256()
        for path in sorted(self.root.rglob('*')):
            if path.is_file():
                digest.update(path.relative_to(self.root).as_posix().encode('utf-8'))
                digest.update(path.read_bytes())
        return digest.hexdigest()

    def cli(self, *args):
        return subprocess.run([sys.executable, '-B', str(TOOLS / 'kb.py'), *args,
                               '--root', str(self.root)],
                              capture_output=True, text=True, timeout=120)

    def test_exact_claim_id_retrieval(self):
        result = self.query('term.targetid.sha1')
        self.assertEqual(result['result'], 'matches')
        self.assertEqual(result['claims'][0]['id'], 'term.targetid.sha1')
        self.assertEqual(result['claims'][0]['score_breakdown']['id_exact'], 100.0)

    def test_technical_identifier_retrieval(self):
        result = self.query('How is TargetId generated?')
        self.assertEqual(result['claims'][0]['id'], 'term.targetid.sha1')

    def test_identifier_ranks_above_generic(self):
        # Exact technical identifier (TargetId) must outrank a claim that matches only
        # the generic domain vocabulary (targets/campaign) split out of the identifier.
        result = self.query('How is TargetId generated?')
        ids = [c['id'] for c in result['claims']]
        self.assertIn('term.targetid.sha1', ids)
        self.assertIn('business.workflow.targets', ids)
        self.assertLess(ids.index('term.targetid.sha1'), ids.index('business.workflow.targets'))

    def test_broad_domain_query_preserved(self):
        # A broader domain question about generic "targets" must still retrieve the
        # business-workflow claim (business context is not sacrificed for identifier focus).
        result = self.query('How are targets used in the campaign content workflow?')
        self.assertEqual(result['claims'][0]['id'], 'business.workflow.targets')

    def test_russian_term_retrieval(self):
        result = self.query('Где хранится статистика?')
        self.assertIn('business.stats.storage', [c['id'] for c in result['claims']])

    def test_scoped_retrieval(self):
        self.assertEqual(self.query('hash', scope=['ClickHouse'])['result'], 'insufficient-evidence')
        result = self.query('статистика', scope=['ClickHouse'])
        self.assertEqual(result['claims'][0]['id'], 'business.stats.storage')
        self.assertEqual(self.query('статистика', scope=['nonexistent-scope'])['result'],
                         'insufficient-evidence')

    def test_evidence_inclusion(self):
        result = self.query('TargetId')
        top = next(c for c in result['claims'][:2] if c['id'] == 'term.targetid.sha1')
        self.assertEqual(top['evidence_ids'], ['ev.targetid'])
        ref = next(e for e in result['evidence'] if e['id'] == 'ev.targetid')
        self.assertEqual(ref['source'], 'IPM/Src/Common/Entities/Targets/TargetId.cs')
        self.assertIn('TargetId.Create', ref['location'])
        self.assertEqual(ref['status'], 'active')

    def test_missing_evidence_fails_safely(self):
        path = (self.root / '.ai' / GROUPS['claims'] / 'broken.missing-evidence.json')
        record = dict(CLAIMS[0], id='broken.missing-evidence', evidence=['ev.missing'])
        path.write_text(canonical_json(record), encoding='utf-8')
        self.addCleanup(path.unlink)
        with self.assertRaises(ContextEngineError) as context:
            self.query('TargetId')
        self.assertEqual(str(context.exception), 'invalid-canonical-dataset-run-validate')

    def test_conflict_exposure(self):
        result = self.query('TargetId SHA1 hash')
        self.assertNotIn('term.targetid.legacy', [c['id'] for c in result['claims']])
        conflict = next(c for c in result['conflicts'] if c['partner_id'] == 'term.targetid.legacy')
        self.assertEqual(conflict['claim_id'], 'term.targetid.sha1')
        self.assertEqual(conflict['partner_status'], 'NEEDS_HUMAN_CONFIRMATION')
        self.assertFalse(conflict['partner_confirmed'])
        self.assertIn('not an active rule', conflict['note'])

    def test_unconfirmed_filtering(self):
        default = self.query('TargetId SHA1 hash')
        self.assertNotIn('NEEDS_HUMAN_CONFIRMATION', [c['status'] for c in default['claims']])
        opened = self.query('TargetId SHA1 hash', include_unconfirmed=True)
        legacy = next(c for c in opened['claims'] if c['id'] == 'term.targetid.legacy')
        self.assertFalse(legacy['confirmed'])
        self.assertEqual(legacy['status'], 'NEEDS_HUMAN_CONFIRMATION')

    def test_no_match(self):
        result = self.query('quantum entanglement')
        self.assertEqual(result['result'], 'insufficient-evidence')
        self.assertEqual(result['claims'], [])
        self.assertIsNotNone(result['message'])

    def test_duplicate_evidence_deduplicated(self):
        result = self.query('TargetId')
        ids = [c['id'] for c in result['claims']]
        self.assertIn('term.targetid.sha1', ids)
        self.assertIn('term.targetid.rationale', ids)
        self.assertEqual(sum(1 for e in result['evidence'] if e['id'] == 'ev.targetid'), 1)

    def test_deterministic_output(self):
        first = self.query('How is TargetId generated?')
        second = self.query('How is TargetId generated?')
        self.assertEqual(json.dumps(first, sort_keys=True, ensure_ascii=False),
                         json.dumps(second, sort_keys=True, ensure_ascii=False))

    def test_token_budget_enforced(self):
        full = self.query('TargetId', max_tokens=2000)
        self.assertTrue(full['claims'])
        self.assertLessEqual(full['budget']['estimated_tokens'], 2000)
        tiny = self.query('TargetId', max_tokens=1)
        self.assertEqual(tiny['claims'], [])
        self.assertEqual(tiny['truncation']['reason'], 'budget-exhausted-by-envelope')
        exact = self.query('TargetId', max_tokens=full['budget']['estimated_tokens'])
        self.assertEqual([c['id'] for c in exact['claims']], [c['id'] for c in full['claims']])

    def test_compact_mode_shape(self):
        result = self.query('How is TargetId generated?', compact=True)
        self.assertEqual(result['view'], 'compact')
        # No query echo, no diagnostic ranking internals.
        self.assertNotIn('query', result)
        self.assertEqual(set(result['knowledge_base']), {'fingerprint'})
        self.assertTrue(result['knowledge_base']['fingerprint'].startswith('sha256:'))
        for claim in result['claims']:
            for key in ('score', 'score_breakdown', 'reasons'):
                self.assertNotIn(key, claim)
            for key in ('id', 'status', 'confirmed', 'type', 'statement',
                        'last_verified', 'evidence_ids', 'conflicts_with'):
                self.assertIn(key, claim)
        for ref in result['evidence']:
            for key in ('id', 'source', 'location', 'status'):
                self.assertIn(key, ref)
            for key in ('type', 'captured_at'):
                self.assertNotIn(key, ref)
        self.assertIn('truncation', result)
        self.assertIn('result', result)

    def test_compact_diagnostic_same_ranking(self):
        diagnostic = self.query('How is TargetId generated?')
        compact = self.query('How is TargetId generated?', compact=True)
        self.assertEqual([c['id'] for c in diagnostic['claims']],
                         [c['id'] for c in compact['claims']])

    def test_compact_budget_applied_to_compact_representation(self):
        # The budget is enforced against the compact serialization, so at the same
        # max_tokens the compact view fits at least as many claims as the diagnostic view.
        diagnostic = self.query('TargetId', max_tokens=2000)
        compact = self.query('TargetId', max_tokens=2000, compact=True)
        self.assertLessEqual(len(diagnostic['claims']), len(compact['claims']))
        self.assertLessEqual(compact['budget']['estimated_tokens'], 2000)
        self.assertEqual(compact['budget']['estimation'], 'utf8-bytes/4')

    def test_cli_json_validity(self):
        proc = self.cli('context', '--task', 'TargetId', '--json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertTrue(data['ok'])
        self.assertIn('term.targetid.sha1', [c['id'] for c in data['claims']])
        self.assertEqual(data['knowledge_base']['claim_count'], 6)

    def test_cli_compact_validity(self):
        proc = self.cli('context', '--task', 'TargetId', '--compact', '--json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertTrue(data['ok'])
        self.assertEqual(data['view'], 'compact')
        self.assertNotIn('score', data['claims'][0])
        self.assertNotIn('score_breakdown', data['claims'][0])
        self.assertNotIn('reasons', data['claims'][0])
        self.assertTrue(data['knowledge_base']['fingerprint'].startswith('sha256:'))
        self.assertLessEqual(data['budget']['estimated_tokens'], 2000)

    def test_compact_flag_rejected_by_other_commands(self):
        proc = self.cli('validate', '--compact')
        self.assertNotEqual(proc.returncode, 0)

    def test_read_only_and_no_writes(self):
        before = self.tree_digest()
        self.query('How is TargetId generated?')
        self.cli('context', '--task', 'TargetId', '--json')
        self.assertEqual(self.tree_digest(), before)

    def test_windows_path_handling(self):
        if os.name != 'nt':
            self.skipTest('Windows path handling test requires Windows')
        self.assertIn('\\', str(self.root))
        result = self.query('TargetId')
        for ref in result['evidence']:
            self.assertNotIn('\\', ref['source'])
            self.assertNotIn('\\', ref['location'] or '')

    def test_malformed_input(self):
        proc = self.cli('context', '--json')
        self.assertNotEqual(proc.returncode, 0)
        with self.assertRaises(ContextEngineError):
            self.query('   ')
        with self.assertRaises(ContextEngineError):
            self.query('TargetId', max_tokens=0)
        path = (self.root / '.ai' / GROUPS['claims'] / 'term.targetid.sha1.json')
        original = path.read_text(encoding='utf-8')
        self.addCleanup(path.write_text, original, encoding='utf-8')
        path.write_text('not-json', encoding='utf-8')
        with self.assertRaises(ContextEngineError):
            self.query('TargetId')

    def test_context_flags_rejected_by_other_commands(self):
        proc = self.cli('validate', '--task', 'TargetId')
        self.assertNotEqual(proc.returncode, 0)


if __name__ == '__main__':
    unittest.main()
