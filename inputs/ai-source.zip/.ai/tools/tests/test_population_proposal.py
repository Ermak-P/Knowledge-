"""Native tests for the reviewed-proposal population extension (add-only import).

Run: python -B -m unittest discover -s .ai/tools/tests -p 'test_*.py'
Fixtures are disposable synthetic repositories in a temp directory on the local
filesystem; the host repository's canonical records are never touched.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS))

import kb
from population_normalize import GROUPS, load_canonical
from population_transaction import (PopulationError, PopulationStore, canonical_json,
                                    encoded, read_bytes, read_json, sha, write_new)

CLAIM = {
    'id': 'business.test.rule', 'statement': 'Test business rule statement.',
    'type': 'business_rule', 'status': 'CONFIRMED', 'evidence': ['ev.test.rule'],
    'provenance': {'actor': 'test-author', 'method': 'test-interview'},
    'last_verified': '2026-10-19', 'depends_on': [], 'conflicts_with': []}
CLAIM_EVIDENCE = {
    'id': 'ev.test.rule', 'type': 'direct-authoritative', 'status': 'active',
    'source': 'test-interview.md', 'provenance': {'actor': 'test-author', 'method': 'test-interview'},
    'captured_at': '2026-10-19T12:00:00Z', 'location': 'test-interview.md#L1',
    'description': 'Supports the test business rule.', 'content_hash': 'sha256:' + '0' * 64,
    'substantiates': ['business.test.rule']}
FACT = {
    'id': 'technical.test.fact', 'statement': 'Test technical fact statement.',
    'type': 'technical_fact', 'status': 'NEEDS_HUMAN_CONFIRMATION', 'evidence': ['ev.test.fact'],
    'provenance': {'actor': 'test-scanner', 'method': 'test-scan'},
    'last_verified': None, 'depends_on': [], 'conflicts_with': []}
FACT_EVIDENCE = {
    'id': 'ev.test.fact', 'type': 'direct-technical', 'status': 'active',
    'source': 'A.csproj', 'provenance': {'actor': 'test-scanner', 'method': 'test-scan'},
    'captured_at': '2026-10-19T12:00:00Z', 'location': 'A.csproj#L1',
    'description': 'Supports the test technical fact.', 'content_hash': 'sha256:' + '1' * 64,
    'substantiates': ['technical.test.fact']}
DEFAULT_RECORDS = [('claims', CLAIM), ('evidence', CLAIM_EVIDENCE),
                   ('claims', FACT), ('evidence', FACT_EVIDENCE)]


def init_target(root):
    errors = kb.init(root / '.ai')
    assert not errors, errors


def write_proposal(root, records=DEFAULT_RECORDS, manifest=True):
    base = root / '.ai'
    if base.exists():
        shutil.rmtree(base)
    for directory in GROUPS.values():
        (base / directory).mkdir(parents=True, exist_ok=True)
    if manifest:
        shutil.copyfile(TOOLS.parent / 'manifest.yaml', base / 'manifest.yaml')
    for group, record in records:
        (base / GROUPS[group] / (record['id'] + '.json')).write_text(
            canonical_json(record), encoding='utf-8')


def run_script(script, timeout=60):
    return subprocess.run([sys.executable, '-B', '-c', script],
                          capture_output=True, text=True, timeout=timeout)


class ProposalPopulationTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory(prefix='kb-proposal-')
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name) / 'target'
        self.proposal = Path(self._tmp.name) / 'proposal'
        self.root.mkdir()
        self.proposal.mkdir()
        init_target(self.root)
        write_proposal(self.proposal)
        self.store = PopulationStore(self.root)

    def prepare(self):
        return self.store.prepare(proposal=self.proposal)

    def test_prepare_plan_shape(self):
        result = self.prepare()
        self.assertTrue(result['ok'])
        plan = result['plan']
        self.assertEqual(plan['mode'], 'reviewed-proposal')
        self.assertEqual(plan['policy'], 'add-only-entire-plan')
        self.assertTrue(plan['applicable'])
        self.assertEqual(plan['blocked'], [])
        self.assertEqual(len(plan['eligible']), 4)
        self.assertEqual({op['record_type'] for op in plan['eligible']}, {'claims', 'evidence'})
        self.assertTrue(all(op['action'] == 'add' for op in plan['eligible']))
        self.assertEqual(self.store.canonical_snapshot(), plan['canonical'])
        self.assertEqual(kb.validate(self.store.base)[0], [])

    def test_apply_requires_exact_approval(self):
        plan_id = self.prepare()['fingerprint']
        with self.assertRaises(PopulationError) as context:
            self.store.apply(plan_id)
        self.assertEqual(str(context.exception),
                         'exact-plan-approval-required-use-approve-fingerprint')
        with self.assertRaises(PopulationError) as context:
            self.store.apply(plan_id, approve='sha256:' + '0' * 64)
        self.assertEqual(str(context.exception), 'approval-fingerprint-mismatch')
        self.assertEqual(load_canonical(self.store.base),
                         {group: [] for group in GROUPS})

    def test_apply_installs_and_validates(self):
        plan = self.prepare()['plan']
        result = self.store.apply(plan['fingerprint'], approve=plan['fingerprint'])
        self.assertTrue(result['ok'])
        self.assertEqual(result['state'], 'COMMITTED')
        self.assertEqual(result['writes'], 4)
        records = load_canonical(self.store.base)
        self.assertEqual(len(records['claims']), 2)
        self.assertEqual(len(records['evidence']), 2)
        self.assertEqual(kb.validate(self.store.base)[0], [])
        for op in plan['eligible']:
            self.assertEqual(sha(read_bytes(self.store.base / op['path'], False)), op['hash'])

    def test_apply_idempotent_retry(self):
        plan_id = self.prepare()['fingerprint']
        self.assertTrue(self.store.apply(plan_id, approve=plan_id)['ok'])
        second = self.store.apply(plan_id, approve=plan_id)
        self.assertTrue(second['already_applied'])
        self.assertEqual(second['writes'], 0)

    def test_id_collision_blocks_plan(self):
        write_new(self.store.base / self.store.target('claims', CLAIM['id']), encoded(CLAIM))
        plan = self.prepare()['plan']
        self.assertFalse(plan['applicable'])
        collisions = [entry for entry in plan['blocked'] if entry['id'] == CLAIM['id']]
        self.assertEqual(collisions[0]['reasons'], ['existing-id-collision'])
        with self.assertRaises(PopulationError) as context:
            self.store.apply(plan['fingerprint'], approve=plan['fingerprint'])
        self.assertIn('blocked-plan', str(context.exception))

    def test_target_path_occupied_blocks_plan(self):
        other = dict(CLAIM)
        other.update(id='business.other', statement='Other statement.',
                     evidence=['ev.test.rule'])
        write_new(self.store.base / self.store.target('claims', CLAIM['id']), encoded(other))
        plan = self.prepare()['plan']
        self.assertFalse(plan['applicable'])
        collisions = [entry for entry in plan['blocked'] if entry['id'] == CLAIM['id']]
        self.assertEqual(collisions[0]['reasons'], ['target-path-occupied'])

    def test_stale_proposal_rejected(self):
        plan_id = self.prepare()['fingerprint']
        changed = dict(CLAIM)
        changed['statement'] = 'Changed statement.'
        (self.proposal / '.ai/knowledge/claims/business.test.rule.json').write_text(
            canonical_json(changed), encoding='utf-8')
        with self.assertRaises(PopulationError) as context:
            self.store.apply(plan_id, approve=plan_id)
        self.assertEqual(str(context.exception), 'stale-proposal-inputs-prepare-again')

    def test_confirmed_without_direct_evidence_rejected(self):
        evidence = dict(CLAIM_EVIDENCE)
        evidence['type'] = 'supporting'
        write_proposal(self.proposal, [('claims', CLAIM), ('evidence', evidence)])
        with self.assertRaises(PopulationError) as context:
            self.prepare()
        self.assertEqual(str(context.exception), 'invalid-proposal-dataset')

    def test_dangling_evidence_reference_rejected(self):
        claim = dict(CLAIM)
        claim['evidence'] = ['ev.missing']
        write_proposal(self.proposal, [('claims', claim), ('evidence', CLAIM_EVIDENCE)])
        with self.assertRaises(PopulationError) as context:
            self.prepare()
        self.assertEqual(str(context.exception), 'invalid-proposal-dataset')

    def test_cross_store_reference_rejected(self):
        # A proposal must be self-contained: an evidence ID that exists only in the
        # target store is not visible to the isolated proposal validation.
        human_ev = dict(CLAIM_EVIDENCE)
        human_ev.update(id='ev.human.rule', substantiates=['business.test.rule'])
        write_new(self.store.base / self.store.target('evidence', human_ev['id']),
                  encoded(human_ev))
        claim = dict(FACT)
        claim['evidence'] = ['ev.human.rule']
        write_proposal(self.proposal, [('claims', claim)])
        with self.assertRaises(PopulationError) as context:
            self.prepare()
        self.assertEqual(str(context.exception), 'invalid-proposal-dataset')

    def test_empty_proposal_rejected(self):
        write_proposal(self.proposal, [])
        with self.assertRaises(PopulationError) as context:
            self.prepare()
        self.assertEqual(str(context.exception), 'empty-proposal')

    def test_missing_manifest_rejected(self):
        write_proposal(self.proposal, manifest=False)
        with self.assertRaises(PopulationError) as context:
            self.prepare()
        self.assertEqual(str(context.exception), 'proposal-manifest-required')

    def test_same_root_rejected(self):
        with self.assertRaises(PopulationError) as context:
            self.store.prepare(proposal=self.root)
        self.assertEqual(str(context.exception), 'proposal-root-must-differ-from-target')

    def test_linked_proposal_rejected(self):
        link = self.proposal / '.ai/knowledge/claims/linked-dir'
        target_dir = self.proposal / 'outside'
        target_dir.mkdir()
        try:
            os.symlink(target_dir, link, target_is_directory=True)
        except (OSError, PermissionError, AttributeError, ValueError):
            subprocess.run(['cmd', '/c', 'mklink', '/J', str(link), str(target_dir)],
                           capture_output=True, text=True)
        if not link.exists():
            self.skipTest('symlink/junction creation not permitted on this host')
        self.addCleanup(lambda: os.rmdir(link) if link.is_dir() and not link.is_symlink() else None)
        with self.assertRaises(PopulationError) as context:
            self.prepare()
        self.assertEqual(str(context.exception), 'proposal-tree-contains-links-or-unsafe-paths')

    def test_existing_records_preserved(self):
        human_claim = dict(CLAIM)
        human_claim.update(id='business.human.rule', evidence=['ev.human.rule'])
        human_ev = dict(CLAIM_EVIDENCE)
        human_ev.update(id='ev.human.rule', substantiates=['business.human.rule'])
        claim_path = self.store.base / self.store.target('claims', human_claim['id'])
        evidence_path = self.store.base / self.store.target('evidence', human_ev['id'])
        write_new(claim_path, encoded(human_claim))
        write_new(evidence_path, encoded(human_ev))
        before = {str(path): sha(read_bytes(path, False)) for path in [claim_path, evidence_path]}
        plan_id = self.prepare()['fingerprint']
        self.assertTrue(self.store.apply(plan_id, approve=plan_id)['ok'])
        after = {str(path): sha(read_bytes(path, False)) for path in [claim_path, evidence_path]}
        self.assertEqual(before, after)
        records = load_canonical(self.store.base)
        self.assertEqual(len(records['claims']), 3)
        self.assertEqual(len(records['evidence']), 3)
        self.assertEqual(kb.validate(self.store.base)[0], [])

    def test_relationship_import(self):
        fact = dict(FACT)
        fact['depends_on'] = ['business.test.rule']
        relation = {'id': 'rel.test.depends', 'type': 'depends_on',
                    'from': 'technical.test.fact', 'to': 'business.test.rule',
                    'provenance': {'actor': 'test-author', 'method': 'test-interview'}}
        write_proposal(self.proposal, [('claims', CLAIM), ('evidence', CLAIM_EVIDENCE),
                                       ('claims', fact), ('evidence', FACT_EVIDENCE),
                                       ('relationships', relation)])
        plan = self.prepare()['plan']
        self.assertTrue(plan['applicable'])
        self.assertEqual(len(plan['eligible']), 5)
        result = self.store.apply(plan['fingerprint'], approve=plan['fingerprint'])
        self.assertEqual(result['writes'], 5)
        records = load_canonical(self.store.base)
        self.assertEqual(len(records['relationships']), 1)
        self.assertEqual(kb.validate(self.store.base)[0], [])

    def test_interrupted_apply_recovers(self):
        plan_id = self.prepare()['fingerprint']
        script = (
            'import os, sys\n'
            f'sys.path.insert(0, {str(TOOLS)!r})\n'
            'import population_transaction as tx\n'
            'def stop(phase, index=None):\n'
            "    if phase == 'after_install' and index == 0:\n"
            '        os._exit(71)\n'
            'tx._checkpoint = stop\n'
            f'tx.PopulationStore({str(self.root)!r}).apply({plan_id!r}, {plan_id!r})\n')
        process = run_script(script)
        self.assertEqual(process.returncode, 71, process.stderr)
        status = self.store.status(plan_id)
        self.assertTrue(status['recovery_required'])
        result = self.store.recover(plan_id)
        self.assertEqual(result['state'], 'ROLLED_BACK')
        self.assertEqual(load_canonical(self.store.base), {group: [] for group in GROUPS})
        self.assertEqual(kb.validate(self.store.base)[0], [])

    def test_concurrent_apply_busy_then_retry(self):
        plan_id = self.prepare()['fingerprint']
        script = (
            'import sys, time\n'
            f'sys.path.insert(0, {str(TOOLS)!r})\n'
            'import population_transaction as tx\n'
            f'store = tx.PopulationStore({str(self.root)!r})\n'
            'with store.coordinate():\n'
            "    (store.state / 'holder-ready').write_bytes(b'1')\n"
            '    time.sleep(30)\n')
        holder = subprocess.Popen([sys.executable, '-B', '-c', script])
        try:
            deadline = time.time() + 30
            while not (self.store.state / 'holder-ready').exists() and time.time() < deadline:
                time.sleep(0.2)
            self.assertTrue((self.store.state / 'holder-ready').exists(),
                            'lock holder did not signal readiness')
            with self.assertRaises(PopulationError) as context:
                self.store.apply(plan_id, approve=plan_id)
            self.assertEqual(str(context.exception),
                             'population-busy-retry-after-current-operation')
        finally:
            holder.terminate()
            holder.wait(timeout=60)
        result = self.store.apply(plan_id, approve=plan_id)
        self.assertEqual(result['state'], 'COMMITTED')


class RepositoryModeRegressionTests(unittest.TestCase):
    def test_repository_scan_flow_unchanged(self):
        with tempfile.TemporaryDirectory(prefix='kb-repo-') as name:
            repo = Path(name)
            init_target(repo)
            (repo / 'A.csproj').write_text(
                '<Project><PropertyGroup><TargetFramework>net10.0</TargetFramework>'
                '</PropertyGroup><ItemGroup><ProjectReference Include="B.csproj"/>'
                '</ItemGroup></Project>', encoding='utf-8')
            (repo / 'B.csproj').write_text('<Project/>', encoding='utf-8')
            store = PopulationStore(repo)
            result = store.prepare()
            self.assertTrue(result['ok'], result)
            plan = result['plan']
            self.assertNotEqual(plan.get('mode', 'repository-scan'), 'reviewed-proposal')
            self.assertTrue(plan['applicable'], plan['blocked'])
            applied = store.apply(result['fingerprint'], approve=result['fingerprint'])
            self.assertEqual(applied['state'], 'COMMITTED')
            self.assertEqual(kb.validate(store.base)[0], [])
            records = load_canonical(store.base)
            self.assertTrue(records['claims'])
            for record in records['claims']:
                self.assertEqual(record['type'], 'technical_fact')
                self.assertEqual(record['status'], 'NEEDS_HUMAN_CONFIRMATION')
                self.assertIsNone(record['last_verified'])


if __name__ == '__main__':
    unittest.main()
