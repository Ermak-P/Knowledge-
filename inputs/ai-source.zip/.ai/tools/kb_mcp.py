"""Local stdio MCP server for the canonical .ai knowledge base (Stage 6.2).

Read-only exposure of Contract v1.0 knowledge to local coding agents over MCP
stdio. Reuses Context Engine v1 (context_engine.ContextEngine) and the
unmodified Contract v1.0 validator (kb.validate via validate_records).

Transport: JSON-RPC/MCP exclusively on stdout; diagnostics on stderr only.
No daemon, no TCP/HTTP, no outbound network, no canonical writes, no telemetry.

Launch (Windows, any working directory):
    python -B <repo>/.ai/tools/kb_mcp.py
    python -B <repo>/.ai/tools/kb_mcp.py --root <repo>
"""
import argparse
import logging
import re
import sys
from pathlib import Path

# This file lives at <repo>/.ai/tools/kb_mcp.py; make the sibling modules
# importable regardless of the caller's current working directory.
TOOLS = Path(__file__).resolve().parent
if str(TOOLS) not in sys.path:
    sys.path.insert(0, str(TOOLS))

import kb  # noqa: E402  (Contract v1.0 validator and path safety checks)
from context_engine import (  # noqa: E402
    CONFIRMED, ContextEngine, ContextEngineError, conflict_note)
from population_normalize import load_canonical, validate_records  # noqa: E402
from population_transaction import PopulationError, normal_operation  # noqa: E402
from mcp.server.fastmcp import FastMCP  # noqa: E402

SERVER_NAME = 'ipm-knowledge'
SERVER_VERSION = '1.0.0'

# Budget policy (see docs/mcp-server.md): the token figure is an estimate
# (utf8-bytes/4), not an exact tokenizer count. Stage 6.1.1 measured a 6-28%
# underestimation versus the local Qwen tokenizer for this JSON output, so the
# default below is sized conservatively for a local coding agent and the hard
# cap prevents unbounded tool responses.
DEFAULT_MAX_TOKENS = 1500
MAX_MAX_TOKENS = 8000
DEFAULT_MAX_ITEMS = 10
MAX_MAX_ITEMS = 25
MAX_TASK_LENGTH = 2000
MAX_SCOPE_ITEMS = 10
MAX_SCOPE_ITEM_LENGTH = 200
MAX_ID_LENGTH = 128
# Contract v1.0 claim/evidence id pattern (schema/*.schema.json, hash-pinned in kb.py).
# Dictionary lookup only: a valid-looking id never becomes a filesystem path.
ID_PATTERN = re.compile(r'^[A-Za-z][A-Za-z0-9._:-]*$')

BUDGET_NOTE = ('estimated tokens (utf8-bytes/4), not an exact tokenizer count; '
               'Stage 6.1.1 measured ~6-28% underestimation vs the local Qwen tokenizer')

ROOT = None  # Resolved once in main() before serving; never CWD-dependent.


class KbMcpError(ValueError):
    """Stable actionable error code, never a source-content or OS-path dump."""


def resolve_root(cli_root):
    """Deterministic host-repository root, independent of the caller's CWD.

    Explicit --root wins; otherwise the repository containing this file
    (<repo>/.ai/tools/kb_mcp.py). No private username-specific path is
    hardcoded. Rejects missing roots, linked roots and linked .ai trees.
    """
    root = Path(cli_root) if cli_root else Path(__file__).resolve().parents[2]
    if root.is_symlink() or root.is_junction() or not root.is_dir():
        raise KbMcpError('invalid-root')
    base = root.resolve() / '.ai'
    try:
        kb.check_paths(base)
    except ValueError:
        raise KbMcpError('unsafe-canonical-path')
    if not (base / 'manifest.yaml').is_file():
        raise KbMcpError('invalid-root')
    return root


def load_validated(root):
    """Validated canonical snapshot under the existing coordinator read-guard.

    Same load+validate pipeline as Context Engine v1: strict JSON, no symlinks
    or junctions, UNMODIFIED Contract v1.0 validator on an isolated temp dataset.
    Read-only with respect to .ai (the temp staging dir is disposable).
    """
    try:
        guard = normal_operation(root)
    except PopulationError:
        raise KbMcpError('population-busy-or-recovery-required')
    with guard:
        base = Path(root).resolve() / '.ai'
        try:
            records = load_canonical(base)
            validation = validate_records(base, records)
        except (OSError, ValueError, TypeError, KeyError, AttributeError, re.error):
            raise KbMcpError('invalid-canonical-dataset-run-validate')
        if not validation['ok']:
            raise KbMcpError('invalid-canonical-dataset-run-validate')
        return records


def check_identifier(value, code):
    """Exact canonical identifier: bounded length, Contract v1.0 pattern.

    Rejects empty values, path traversal ('..', '/', '\\') and any malformed
    identifier with a stable code before any record lookup.
    """
    if (not isinstance(value, str) or not value or len(value) > MAX_ID_LENGTH
            or not ID_PATTERN.fullmatch(value)):
        raise KbMcpError(code)


def check_context_args(task, scope, max_tokens, max_items):
    """Input limits for knowledge_context (untrusted input, bounded output)."""
    if not isinstance(task, str) or not task.strip():
        raise KbMcpError('task-must-be-a-non-empty-string')
    if len(task) > MAX_TASK_LENGTH:
        raise KbMcpError('task-too-long')
    if scope is None:
        scope = []
    if (not isinstance(scope, list) or len(scope) > MAX_SCOPE_ITEMS
            or any(not isinstance(value, str) or not value.strip()
                   or len(value) > MAX_SCOPE_ITEM_LENGTH for value in scope)):
        raise KbMcpError('scope-invalid')
    if max_tokens is None:
        max_tokens = DEFAULT_MAX_TOKENS
    if (not isinstance(max_tokens, int) or isinstance(max_tokens, bool)
            or max_tokens < 1):
        raise KbMcpError('max-tokens-must-be-a-positive-integer')
    if max_tokens > MAX_MAX_TOKENS:
        raise KbMcpError('max-tokens-exceeds-limit')
    if max_items is None:
        max_items = DEFAULT_MAX_ITEMS
    if (not isinstance(max_items, int) or isinstance(max_items, bool)
            or max_items < 1):
        raise KbMcpError('max-items-must-be-a-positive-integer')
    if max_items > MAX_MAX_ITEMS:
        raise KbMcpError('max-items-exceeds-limit')
    return task, scope, max_tokens, max_items


def _fail(log, error):
    if isinstance(error, (KbMcpError, ContextEngineError)):
        return {'ok': False, 'errors': [str(error)]}
    log.exception('tool call failed unexpectedly')
    return {'ok': False, 'errors': ['internal-error']}


mcp = FastMCP(
    SERVER_NAME,
    instructions=('Read-only IPM architecture knowledge base (Contract v1.0). '
                  'Use knowledge_context for task-relevant context before coding; '
                  'knowledge_get_claim/knowledge_get_evidence for exact records by ID.'),
)


@mcp.tool()
def knowledge_context(task: str, scope: list[str] | None = None,
                      max_tokens: int | None = None, max_items: int | None = None,
                      include_unconfirmed: bool | None = None) -> dict:
    """Compact, evidence-backed context for a coding task from the IPM architecture knowledge base.

    Use for "how/where/why/what" questions about IPM architecture, components,
    data flow, or business rules before or while coding. Returns relevant claims
    with status, evidence references, historical conflicts, and truncation/budget
    metadata. Only CONFIRMED claims unless include_unconfirmed=true.
    max_tokens is a conservative estimate (bytes/4), not an exact tokenizer count.
    """
    log = logging.getLogger('ipm-knowledge')
    try:
        task, scope, max_tokens, max_items = check_context_args(
            task, scope, max_tokens, max_items)
        result = ContextEngine().query(
            ROOT, task, scope=scope, max_tokens=max_tokens,
            include_unconfirmed=bool(include_unconfirmed), max_items=max_items,
            compact=True)
        result['budget']['note'] = BUDGET_NOTE
        return result
    except (KbMcpError, ContextEngineError) as error:
        return _fail(log, error)
    except Exception:
        return _fail(log, 'unexpected')


@mcp.tool()
def knowledge_get_claim(claim_id: str) -> dict:
    """Exact canonical claim record by ID, with its evidence records and conflict information.

    Use when you already have a claim ID (e.g. from knowledge_context) and need the
    full record: statement, type, status, last_verified, provenance, evidence,
    dependencies, conflicts. Exact ID match only — no search, no file access.
    """
    log = logging.getLogger('ipm-knowledge')
    try:
        check_identifier(claim_id, 'malformed-claim-id')
        records = load_validated(ROOT)
        claim = next((c for c in records['claims'] if c['id'] == claim_id), None)
        if claim is None:
            return {'ok': False, 'errors': ['claim-id-not-found'], 'claim_id': claim_id}
        evidence = {e['id']: e for e in records['evidence']}
        claims = {c['id']: c for c in records['claims']}
        conflicts = []
        for partner_id in claim['conflicts_with']:
            partner = claims.get(partner_id)
            conflicts.append({
                'partner_id': partner_id,
                'partner_status': partner['status'] if partner else None,
                'partner_statement': partner['statement'] if partner else None,
                'partner_confirmed': bool(partner and partner['status'] == CONFIRMED),
                'note': conflict_note(partner),
            })
        return {'ok': True, 'claim': claim,
                'evidence': [evidence[i] for i in claim['evidence'] if i in evidence],
                'conflicts': conflicts}
    except KbMcpError as error:
        return _fail(log, error)
    except Exception:
        return _fail(log, 'unexpected')


@mcp.tool()
def knowledge_get_evidence(evidence_id: str) -> dict:
    """Exact canonical evidence record by ID: type, status, source, location, provenance,
    captured_at, content_hash, and the claims it substantiates.

    Use when you have an evidence ID (e.g. from knowledge_context) and need its
    provenance. Returns the record only — never source-file contents.
    """
    log = logging.getLogger('ipm-knowledge')
    try:
        check_identifier(evidence_id, 'malformed-evidence-id')
        records = load_validated(ROOT)
        item = next((e for e in records['evidence'] if e['id'] == evidence_id), None)
        if item is None:
            return {'ok': False, 'errors': ['evidence-id-not-found'], 'evidence_id': evidence_id}
        return {'ok': True, 'evidence': item}
    except KbMcpError as error:
        return _fail(log, error)
    except Exception:
        return _fail(log, 'unexpected')


def main(argv=None):
    parser = argparse.ArgumentParser(
        description='Local stdio MCP server for the canonical .ai knowledge base (read-only)')
    parser.add_argument('--root', type=Path, default=None,
                        help='host repository directory containing .ai '
                             '(default: the repository containing this file)')
    args = parser.parse_args(argv)
    logging.basicConfig(stream=sys.stderr, level=logging.INFO,
                        format='%(asctime)s %(name)s %(levelname)s %(message)s')
    # The SDK logs every request at INFO; keep stderr to real diagnostics only.
    logging.getLogger('mcp.server').setLevel(logging.WARNING)
    log = logging.getLogger('ipm-knowledge')
    global ROOT
    try:
        ROOT = resolve_root(args.root)
    except KbMcpError as error:
        log.error('startup failed: %s', error)
        return 2
    log.info('%s %s starting on stdio (root from %s)', SERVER_NAME, SERVER_VERSION,
             'cli --root' if args.root else 'script location')
    mcp.run(transport='stdio')
    return 0


if __name__ == '__main__':
    sys.exit(main())
