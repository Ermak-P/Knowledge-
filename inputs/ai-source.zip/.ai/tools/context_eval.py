"""Deterministic evaluation of Context Engine v1 against the canonical .ai repository.

Run: python -B .ai/tools/context_eval.py [--root C:\\Git\\IPM]
Prints a JSON report to stdout. Read-only: never writes to the repository.
Baseline: naive lexical overlap of query tokens with claim statements (no idf,
no field weighting, no synonyms), CONFIRMED claims only.
"""
import argparse
import json
import statistics
import sys
import time
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))

from context_engine import ContextEngine, STOPWORDS, tokenize

MAX_TOKENS = 10000
MAX_ITEMS = 10
RUNS = 3

# Expected relevant claim IDs are based on the actual canonical dataset
# (verified against .ai/knowledge/claims as of the Stage 6.1 baseline).
TASKS = [
    {'id': 'targetid-generation', 'task': 'How is TargetId generated?',
     'expected': ['term.targetid.sha1-current', 'business.target.source-types-current',
                  'business.targetid.sha1-rationale'],
     'conflict_pairs': [['term.targetid.sha1-current', 'term.targetid.sha1'],
                        ['business.target.source-types-current', 'business.target.source-types']]},
    {'id': 'campaign-state-transitions', 'task': 'Campaign state transitions',
     'expected': ['rel.campaign-state-transitions', 'term.contentgroupstate.states',
                  'business.campaign.waiting-states', 'business.distribution.meaning',
                  'rel.campaign-finished-removes-distribution', 'business.campaign.finished-no-delete']},
    {'id': 'campaign-permissions', 'task': 'Campaign permission checks',
     'expected': ['rel.campaign-state-change-roles', 'business.campaign.approval-policy']},
    {'id': 'content-publishing-distribution', 'task': 'Content publishing and distribution',
     'expected': ['business.distribution.meaning', 'distribution.content-file-link-matrix',
                  'term.contentdistributiontype.values', 'term.publicationtype.values',
                  'rel.ds-metadata-republish-task', 'domain.distribution.location',
                  'business.distribution.format-rationale']},
    {'id': 'kafka-topics', 'task': 'Kafka topic configuration and ownership',
     'expected': ['kafka.topics-config-driven', 'kafka.stats.cloudstatistics-prod',
                  'kafka.sss.applicationcontentversion', 'kafka.sss.saleitem',
                  'kafka.sss.contentfilterinfo', 'kafka.dist.targetcontentsubstitutions',
                  'kafka.stats.contentread', 'kafka.sdi.ecomsub-consumergroups']},
    {'id': 'database-responsibilities', 'task': 'Database responsibilities',
     'expected': ['db.mcd.content', 'db.mcd.contentgroup', 'db.mcd.contentfile', 'db.mcd.saleitemterm',
                  'db.dist.publishedcontentinfo', 'db.dist.targetinfo', 'db.ch.clickhouse-stats',
                  'db.sdi.ecomsubsmd', 'db.sdi.licenseentity', 'arch.efcore-sql-scripts']},
    {'id': 'statistics-processing', 'task': 'Statistics processing',
     'expected': ['business.statistics.meaning', 'business.statistics.storage-rationale',
                  'domain.statistics.location', 'db.ch.clickhouse-stats', 'kafka.stats.contentread',
                  'rel.statistics-termcode', 'rel.cloudstats.eventhub-entity',
                  'api.cloudstats.applicationcontentinfo']},
    {'id': 'unknown-question', 'task': 'Describe the weather forecast algorithm used by the accounting department.',
     'expected': [], 'expect_insufficient': True},
    {'id': 'targetid-russian', 'task': 'Как генерируется TargetId?',
     'expected': ['term.targetid.sha1-current', 'business.target.source-types-current',
                  'business.targetid.sha1-rationale']},
    # Regression: broader domain concept (generic "targets") must still be retrieved
    # when the user asks a domain question, in contrast to the exact-identifier
    # TargetId tasks above where the same generic term must NOT outrank the identifier.
    {'id': 'target-workflow-broad', 'task': 'How are targets used in the campaign content workflow?',
     'expected': ['business.workflow.campaign-content-targets', 'business.target.lifecycle']},
]


def baseline_rank(records, task):
    """Naive lexical baseline: raw token overlap with the statement, no idf/weights."""
    query = tokenize(task) - STOPWORDS
    scored = []
    for claim in records['claims']:
        if claim['status'] != 'CONFIRMED':
            continue
        score = len(query & tokenize(claim['statement']))
        if score:
            scored.append((-score, claim['id']))
    scored.sort()
    return [claim_id for _, claim_id in scored]


def recall_at(ranked, expected, k):
    if not expected:
        return None
    return len(set(expected) & set(ranked[:k])) / len(expected)


def precision_at(ranked, expected, k):
    if not expected:
        return None
    return len(set(expected) & set(ranked[:k])) / k


def evaluate_task(engine, root, spec, records):
    latencies = []
    results = []
    for _ in range(RUNS):
        started = time.perf_counter()
        result = engine.query(root, spec['task'], max_tokens=MAX_TOKENS, max_items=MAX_ITEMS)
        latencies.append((time.perf_counter() - started) * 1000.0)
        results.append(result)
    result = results[0]
    deterministic = all(json.dumps(result, sort_keys=True, ensure_ascii=False)
                        == json.dumps(other, sort_keys=True, ensure_ascii=False)
                        for other in results[1:])
    top = [claim['id'] for claim in result['claims']]
    expected = set(spec['expected'])
    row = {
        'task_id': spec['id'],
        'task': spec['task'],
        'engine': {
            'result': result['result'],
            'top': top,
            'recall_at_5': recall_at(top, expected, 5),
            'recall_at_10': recall_at(top, expected, 10),
            'precision_at_5': precision_at(top, expected, 5),
            'context_tokens': result['budget']['estimated_tokens'],
            'latency_ms_median': round(statistics.median(latencies), 2),
            'deterministic': deterministic,
        },
        'baseline': {
            'top': baseline_rank(records, spec['task'])[:10],
            'recall_at_5': recall_at(baseline_rank(records, spec['task']), expected, 5),
            'recall_at_10': recall_at(baseline_rank(records, spec['task']), expected, 10),
        },
    }
    if expected:
        evidence_ids = {e['id'] for e in result['evidence']}
        covered = 0
        for claim in result['claims']:
            if claim['id'] in expected and set(claim['evidence_ids']) <= evidence_ids:
                covered += 1
        row['engine']['evidence_coverage'] = covered / len(expected)
    if 'conflict_pairs' in spec:
        pairs = {frozenset((c['claim_id'], c['partner_id'])) for c in result['conflicts']}
        row['engine']['conflicts_exposed'] = all(frozenset(pair) in pairs for pair in spec['conflict_pairs'])
    if spec.get('expect_insufficient'):
        row['engine']['insufficient_correct'] = (result['result'] == 'insufficient-evidence'
                                                 and result['claims'] == [])
    return row


def main():
    parser = argparse.ArgumentParser(description='Context Engine v1 deterministic evaluation')
    parser.add_argument('--root', type=Path, default=TOOLS.parents[1],
                        help='host repository directory containing .ai (default: repository root)')
    args = parser.parse_args()
    engine = ContextEngine()
    first = engine.query(args.root, TASKS[0]['task'], max_tokens=MAX_TOKENS, max_items=MAX_ITEMS)
    from population_normalize import load_canonical
    records = load_canonical(args.root.resolve() / '.ai')
    rows = [evaluate_task(engine, args.root, spec, records) for spec in TASKS]

    def mean(key, section='engine'):
        values = [row[section][key] for row in rows if row[section].get(key) is not None]
        return round(sum(values) / len(values), 4) if values else None

    report = {
        'engine_version': first['engine_version'],
        'knowledge_base': first['knowledge_base'],
        'settings': {'max_tokens': MAX_TOKENS, 'max_items': MAX_ITEMS, 'runs': RUNS},
        'tasks': rows,
        'aggregates': {
            'engine_recall_at_5': mean('recall_at_5'),
            'engine_recall_at_10': mean('recall_at_10'),
            'engine_precision_at_5': mean('precision_at_5'),
            'engine_evidence_coverage': mean('evidence_coverage'),
            'engine_context_tokens': mean('context_tokens'),
            'engine_latency_ms_median': mean('latency_ms_median'),
            'engine_deterministic': all(row['engine']['deterministic'] for row in rows),
            'baseline_recall_at_5': mean('recall_at_5', 'baseline'),
            'baseline_recall_at_10': mean('recall_at_10', 'baseline'),
            'conflicts_exposed': all(row['engine']['conflicts_exposed']
                                     for row in rows if 'conflicts_exposed' in row['engine']),
            'unknown_handled': all(row['engine']['insufficient_correct']
                                   for row in rows if 'insufficient_correct' in row['engine']),
        },
    }
    print(json.dumps(report, sort_keys=True, ensure_ascii=False, indent=1))
    return 0


if __name__ == '__main__':
    sys.exit(main())
